"use client"

import { SidebarNav } from "@/components/sidebar-nav"
import { Header } from "@/components/header"
import useSWR from "swr"
import { createClient } from "@/lib/supabase/client"

interface DashboardLayoutProps {
  children: React.ReactNode
}

async function fetchUserStats() {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()
  
  if (!user) return null
  
  const { data: profile } = await supabase
    .from("profiles")
    .select("*")
    .eq("id", user.id)
    .single()
  
  return {
    xp: profile?.total_xp || 0,
    level: Math.floor((profile?.total_xp || 0) / 500) + 1,
    streak: profile?.current_streak || 0,
    displayName: profile?.display_name || user.email?.split("@")[0] || "User",
    email: user.email || "",
  }
}

export function DashboardLayout({ children }: DashboardLayoutProps) {
  const { data: userStats } = useSWR("user-stats", fetchUserStats, {
    revalidateOnFocus: false,
  })

  return (
    <div className="min-h-screen bg-background">
      <SidebarNav userStats={userStats || undefined} />
      <div className="pl-64">
        <Header />
        <main className="p-6">{children}</main>
      </div>
    </div>
  )
}
