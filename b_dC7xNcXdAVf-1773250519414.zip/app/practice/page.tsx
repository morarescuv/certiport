import { Suspense } from "react"
import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { getExams, getExamCategories, getQuestions, createQuizAttempt } from "@/lib/database"
import { PracticePageClient } from "./practice-client"

export default async function PracticePage(props: {
  searchParams: Promise<{ exam?: string; mode?: string }>
}) {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  
  if (!user) {
    redirect("/auth/login")
  }

  const searchParams = await props.searchParams
  const examId = searchParams.exam
  const mode = searchParams.mode as "practice" | "test" | undefined

  // Fetch exams and categories
  const [exams, categories] = await Promise.all([
    getExams(),
    getExamCategories(),
  ])

  // If starting a quiz, fetch questions and create attempt
  let questions: Awaited<ReturnType<typeof getQuestions>> = []
  let attemptId: string | null = null
  let selectedExam: typeof exams[0] | null = null

  if (examId && mode) {
    selectedExam = exams.find(e => e.id === examId) || null
    if (selectedExam) {
      const limit = mode === "practice" ? 10 : undefined // Practice mode = 10 questions, test = all
      questions = await getQuestions(examId, limit)
      
      // Create a quiz attempt
      const attempt = await createQuizAttempt(user.id, examId, mode)
      attemptId = attempt.id
    }
  }

  // Map exams with progress (simplified - would normally calculate from user's attempts)
  const examCards = exams.map(exam => ({
    id: exam.id,
    title: exam.name,
    description: exam.description || "",
    duration: `${exam.time_limit_minutes} min`,
    progress: 0,
    difficulty: exam.difficulty as "Easy" | "Medium" | "Hard",
    categoryId: exam.category_id,
  }))

  // Map categories
  const categoryList = categories.map(cat => ({
    id: cat.id,
    name: cat.name,
    icon: cat.icon,
  }))

  // Map questions for quiz engine
  const quizQuestions = questions.map(q => ({
    id: q.id,
    question: q.question_text,
    answers: (q.options || []).map((opt: string, idx: number) => ({
      id: String.fromCharCode(97 + idx),
      text: opt,
      isCorrect: idx === q.correct_answer,
    })),
    explanation: q.explanation || "",
    difficulty: "Medium" as const,
  }))

  return (
    <Suspense fallback={<div className="min-h-screen bg-background" />}>
      <PracticePageClient
        exams={examCards}
        categories={categoryList}
        questions={quizQuestions}
        selectedExam={selectedExam ? {
          id: selectedExam.id,
          title: selectedExam.name,
          timeLimit: selectedExam.time_limit_minutes * 60,
        } : null}
        mode={mode || null}
        attemptId={attemptId}
        userId={user.id}
      />
    </Suspense>
  )
}
