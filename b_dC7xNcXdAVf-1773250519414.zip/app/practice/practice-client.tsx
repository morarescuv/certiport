"use client"

import { useState } from "react"
import { QuizEngine } from "@/components/quiz-engine"
import { DashboardLayout } from "@/components/dashboard-layout"
import { ExamCard } from "@/components/exam-card"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { BookOpen, Filter, Search } from "lucide-react"
import { Input } from "@/components/ui/input"

interface ExamCardData {
  id: string
  title: string
  description: string
  duration: string
  progress: number
  difficulty: "Easy" | "Medium" | "Hard"
  categoryId: string
}

interface Category {
  id: string
  name: string
  icon: string | null
}

interface QuestionData {
  id: string
  question: string
  answers: { id: string; text: string; isCorrect: boolean }[]
  explanation: string
  difficulty: "Easy" | "Medium" | "Hard"
}

interface PracticePageClientProps {
  exams: ExamCardData[]
  categories: Category[]
  questions: QuestionData[]
  selectedExam: { id: string; title: string; timeLimit: number } | null
  mode: "practice" | "test" | null
  attemptId: string | null
  userId: string
}

export function PracticePageClient({
  exams,
  categories,
  questions,
  selectedExam,
  mode,
  attemptId,
  userId,
}: PracticePageClientProps) {
  const [searchQuery, setSearchQuery] = useState("")
  const [activeTab, setActiveTab] = useState("all")

  // If we have an exam selected and mode, show the quiz
  if (selectedExam && mode && questions.length > 0 && attemptId) {
    return (
      <QuizEngine
        examTitle={selectedExam.title}
        questions={questions}
        mode={mode}
        timeLimit={selectedExam.timeLimit}
        attemptId={attemptId}
        userId={userId}
      />
    )
  }

  // Filter exams based on search and category
  const filteredExams = exams.filter(exam => {
    const matchesSearch = exam.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      exam.description.toLowerCase().includes(searchQuery.toLowerCase())
    
    if (activeTab === "all") return matchesSearch
    if (activeTab === "in-progress") return matchesSearch && exam.progress > 0 && exam.progress < 100
    
    // Match by category
    const category = categories.find(c => c.id === exam.categoryId)
    if (activeTab === "microsoft") return matchesSearch && category?.name.toLowerCase().includes("microsoft")
    if (activeTab === "adobe") return matchesSearch && category?.name.toLowerCase().includes("adobe")
    
    return matchesSearch
  })

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-medium text-foreground">Practice Tests</h1>
            <p className="mt-1 text-muted-foreground">
              Choose an exam to practice and improve your skills
            </p>
          </div>
          <div className="flex items-center gap-2">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Search exams..."
                className="pl-9 w-64 bg-muted border-0"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <Button variant="outline" size="icon">
              <Filter className="h-4 w-4" />
              <span className="sr-only">Filter</span>
            </Button>
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="bg-muted">
            <TabsTrigger value="all">All Exams</TabsTrigger>
            <TabsTrigger value="microsoft">Microsoft Office</TabsTrigger>
            <TabsTrigger value="adobe">Adobe</TabsTrigger>
            <TabsTrigger value="in-progress">In Progress</TabsTrigger>
          </TabsList>

          <TabsContent value={activeTab} className="space-y-4">
            {filteredExams.length > 0 ? (
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {filteredExams.map((exam) => (
                  <ExamCard
                    key={exam.id}
                    id={exam.id}
                    title={exam.title}
                    description={exam.description}
                    duration={exam.duration}
                    progress={exam.progress}
                    difficulty={exam.difficulty}
                  />
                ))}
              </div>
            ) : (
              <Card className="border shadow-sm">
                <CardContent className="py-12 text-center">
                  <p className="text-muted-foreground">
                    No exams found matching your search.
                  </p>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>

        <Card className="border shadow-sm">
          <CardHeader>
            <CardTitle className="text-lg font-medium flex items-center gap-2">
              <BookOpen className="h-5 w-5 text-primary" />
              Quick Practice
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground mb-4">
              {"Don't have much time? Try a quick 10-question practice session."}
            </p>
            <div className="flex flex-wrap gap-2">
              {categories.map((category) => (
                <Badge
                  key={category.id}
                  variant="secondary"
                  className="cursor-pointer hover:bg-primary/10 transition-colors px-3 py-1.5"
                  onClick={() => {
                    const categoryExams = exams.filter(e => e.categoryId === category.id)
                    if (categoryExams.length > 0) {
                      window.location.href = `/practice?exam=${categoryExams[0].id}&mode=practice`
                    }
                  }}
                >
                  {category.name}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}
