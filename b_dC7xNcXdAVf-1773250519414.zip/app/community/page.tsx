import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  MessageSquare,
  ThumbsUp,
  Search,
  Filter,
  Plus,
  Clock,
  CheckCircle2,
  Users,
  BookOpen,
  TrendingUp,
} from "lucide-react"

const discussions = [
  {
    id: 1,
    title: "How to use VLOOKUP with multiple criteria?",
    category: "Excel",
    author: "Sarah Chen",
    avatar: "SC",
    replies: 12,
    likes: 24,
    isAnswered: true,
    timeAgo: "2 hours ago",
  },
  {
    id: 2,
    title: "Best practices for Slide Master in PowerPoint",
    category: "PowerPoint",
    author: "Mike Johnson",
    avatar: "MJ",
    replies: 8,
    likes: 15,
    isAnswered: true,
    timeAgo: "5 hours ago",
  },
  {
    id: 3,
    title: "Understanding Word Styles hierarchy",
    category: "Word",
    author: "Emma Wilson",
    avatar: "EW",
    replies: 5,
    likes: 9,
    isAnswered: false,
    timeAgo: "1 day ago",
  },
  {
    id: 4,
    title: "Photoshop layer blending modes explained",
    category: "Photoshop",
    author: "David Park",
    avatar: "DP",
    replies: 18,
    likes: 42,
    isAnswered: true,
    timeAgo: "2 days ago",
  },
  {
    id: 5,
    title: "Excel pivot tables for beginners - step by step guide",
    category: "Excel",
    author: "Lisa Zhang",
    avatar: "LZ",
    replies: 22,
    likes: 56,
    isAnswered: true,
    timeAgo: "3 days ago",
  },
]

const studyGroups = [
  {
    id: 1,
    name: "Excel Masters",
    members: 128,
    topic: "Microsoft Excel",
    activity: "Very Active",
  },
  {
    id: 2,
    name: "Word Wizards",
    members: 95,
    topic: "Microsoft Word",
    activity: "Active",
  },
  {
    id: 3,
    name: "Design Squad",
    members: 67,
    topic: "Adobe Creative Suite",
    activity: "Active",
  },
  {
    id: 4,
    name: "Office Pros",
    members: 234,
    topic: "All Microsoft Office",
    activity: "Very Active",
  },
]

const categoryColors: Record<string, string> = {
  Excel: "bg-success/10 text-success",
  Word: "bg-primary/10 text-primary",
  PowerPoint: "bg-warning/10 text-warning",
  Photoshop: "bg-chart-5/10 text-chart-5",
}

export default function CommunityPage() {
  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-medium text-foreground">Community</h1>
            <p className="mt-1 text-muted-foreground">
              Discuss questions, share tips, and learn together
            </p>
          </div>
          <Button>
            <Plus className="mr-2 h-4 w-4" />
            New Discussion
          </Button>
        </div>

        <div className="flex items-center gap-2">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search discussions..."
              className="pl-9 bg-muted border-0"
            />
          </div>
          <Button variant="outline" size="icon">
            <Filter className="h-4 w-4" />
            <span className="sr-only">Filter</span>
          </Button>
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          <div className="lg:col-span-2">
            <Tabs defaultValue="recent" className="space-y-4">
              <TabsList className="bg-muted">
                <TabsTrigger value="recent">
                  <Clock className="mr-2 h-4 w-4" />
                  Recent
                </TabsTrigger>
                <TabsTrigger value="popular">
                  <TrendingUp className="mr-2 h-4 w-4" />
                  Popular
                </TabsTrigger>
                <TabsTrigger value="unanswered">
                  <MessageSquare className="mr-2 h-4 w-4" />
                  Unanswered
                </TabsTrigger>
              </TabsList>

              <TabsContent value="recent" className="space-y-3">
                {discussions.map((discussion) => (
                  <Card
                    key={discussion.id}
                    className="border shadow-sm hover:shadow-md transition-shadow cursor-pointer"
                  >
                    <CardContent className="p-4">
                      <div className="flex items-start gap-4">
                        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary/20 text-sm font-medium text-primary">
                          {discussion.avatar}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <Badge
                              variant="secondary"
                              className={`border-0 ${categoryColors[discussion.category] || "bg-muted"}`}
                            >
                              {discussion.category}
                            </Badge>
                            {discussion.isAnswered && (
                              <Badge className="bg-success/10 text-success border-0">
                                <CheckCircle2 className="h-3 w-3 mr-1" />
                                Answered
                              </Badge>
                            )}
                          </div>
                          <h3 className="font-medium text-card-foreground line-clamp-1">
                            {discussion.title}
                          </h3>
                          <div className="flex items-center gap-4 mt-2 text-sm text-muted-foreground">
                            <span>{discussion.author}</span>
                            <span>{discussion.timeAgo}</span>
                          </div>
                        </div>
                        <div className="flex items-center gap-4 text-sm text-muted-foreground">
                          <div className="flex items-center gap-1">
                            <MessageSquare className="h-4 w-4" />
                            <span>{discussion.replies}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <ThumbsUp className="h-4 w-4" />
                            <span>{discussion.likes}</span>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </TabsContent>

              <TabsContent value="popular" className="space-y-3">
                {[...discussions]
                  .sort((a, b) => b.likes - a.likes)
                  .map((discussion) => (
                    <Card
                      key={discussion.id}
                      className="border shadow-sm hover:shadow-md transition-shadow cursor-pointer"
                    >
                      <CardContent className="p-4">
                        <div className="flex items-start gap-4">
                          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary/20 text-sm font-medium text-primary">
                            {discussion.avatar}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-1">
                              <Badge
                                variant="secondary"
                                className={`border-0 ${categoryColors[discussion.category] || "bg-muted"}`}
                              >
                                {discussion.category}
                              </Badge>
                              {discussion.isAnswered && (
                                <Badge className="bg-success/10 text-success border-0">
                                  <CheckCircle2 className="h-3 w-3 mr-1" />
                                  Answered
                                </Badge>
                              )}
                            </div>
                            <h3 className="font-medium text-card-foreground line-clamp-1">
                              {discussion.title}
                            </h3>
                            <div className="flex items-center gap-4 mt-2 text-sm text-muted-foreground">
                              <span>{discussion.author}</span>
                              <span>{discussion.timeAgo}</span>
                            </div>
                          </div>
                          <div className="flex items-center gap-4 text-sm text-muted-foreground">
                            <div className="flex items-center gap-1">
                              <MessageSquare className="h-4 w-4" />
                              <span>{discussion.replies}</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <ThumbsUp className="h-4 w-4" />
                              <span>{discussion.likes}</span>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
              </TabsContent>

              <TabsContent value="unanswered" className="space-y-3">
                {discussions
                  .filter((d) => !d.isAnswered)
                  .map((discussion) => (
                    <Card
                      key={discussion.id}
                      className="border shadow-sm hover:shadow-md transition-shadow cursor-pointer"
                    >
                      <CardContent className="p-4">
                        <div className="flex items-start gap-4">
                          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary/20 text-sm font-medium text-primary">
                            {discussion.avatar}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-1">
                              <Badge
                                variant="secondary"
                                className={`border-0 ${categoryColors[discussion.category] || "bg-muted"}`}
                              >
                                {discussion.category}
                              </Badge>
                            </div>
                            <h3 className="font-medium text-card-foreground line-clamp-1">
                              {discussion.title}
                            </h3>
                            <div className="flex items-center gap-4 mt-2 text-sm text-muted-foreground">
                              <span>{discussion.author}</span>
                              <span>{discussion.timeAgo}</span>
                            </div>
                          </div>
                          <div className="flex items-center gap-4 text-sm text-muted-foreground">
                            <div className="flex items-center gap-1">
                              <MessageSquare className="h-4 w-4" />
                              <span>{discussion.replies}</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <ThumbsUp className="h-4 w-4" />
                              <span>{discussion.likes}</span>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
              </TabsContent>
            </Tabs>
          </div>

          <div className="space-y-6">
            <Card className="border shadow-sm">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg font-medium flex items-center gap-2">
                  <Users className="h-5 w-5 text-primary" />
                  Study Groups
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {studyGroups.map((group) => (
                  <div
                    key={group.id}
                    className="flex items-center justify-between rounded-lg bg-muted/50 p-3"
                  >
                    <div>
                      <p className="text-sm font-medium text-card-foreground">
                        {group.name}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {group.members} members
                      </p>
                    </div>
                    <Button variant="outline" size="sm">
                      Join
                    </Button>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card className="border shadow-sm">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg font-medium flex items-center gap-2">
                  <BookOpen className="h-5 w-5 text-primary" />
                  Popular Topics
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {[
                    "VLOOKUP",
                    "Pivot Tables",
                    "Slide Master",
                    "Word Styles",
                    "Formulas",
                    "Charts",
                    "Layers",
                    "Macros",
                    "Templates",
                    "Formatting",
                  ].map((topic) => (
                    <Badge
                      key={topic}
                      variant="secondary"
                      className="cursor-pointer hover:bg-primary/10 transition-colors"
                    >
                      {topic}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="border shadow-sm bg-primary/5">
              <CardContent className="p-5">
                <div className="text-center">
                  <MessageSquare className="h-8 w-8 mx-auto text-primary mb-2" />
                  <h3 className="font-medium text-card-foreground">
                    Need Help?
                  </h3>
                  <p className="text-sm text-muted-foreground mt-1 mb-4">
                    Start a discussion and get answers from the community
                  </p>
                  <Button className="w-full">Ask a Question</Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </DashboardLayout>
  )
}
