import { DashboardLayout } from "@/components/dashboard-layout"
import { BadgeCard } from "@/components/badge-card"
import { StreakCalendar } from "@/components/streak-calendar"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  User,
  Zap,
  Trophy,
  Target,
  Clock,
  Award,
  Flame,
  Star,
  BookOpen,
  CheckCircle2,
  TrendingUp,
  Settings,
} from "lucide-react"

const badges = [
  {
    title: "First Steps",
    description: "Complete your first quiz",
    icon: Star,
    isUnlocked: true,
    rarity: "common" as const,
  },
  {
    title: "Streak Starter",
    description: "Maintain a 3-day streak",
    icon: Flame,
    isUnlocked: true,
    rarity: "common" as const,
  },
  {
    title: "Streak Master",
    description: "Maintain a 7-day streak",
    icon: Flame,
    isUnlocked: true,
    rarity: "rare" as const,
  },
  {
    title: "Perfect Score",
    description: "Score 100% on any quiz",
    icon: Target,
    isUnlocked: true,
    rarity: "rare" as const,
  },
  {
    title: "Word Wizard",
    description: "Complete all Word quizzes",
    icon: BookOpen,
    isUnlocked: false,
    progress: 3,
    target: 5,
    rarity: "epic" as const,
  },
  {
    title: "Excel Expert",
    description: "Complete all Excel quizzes",
    icon: BookOpen,
    isUnlocked: false,
    progress: 2,
    target: 5,
    rarity: "epic" as const,
  },
  {
    title: "Speed Demon",
    description: "Complete a quiz in under 5 minutes",
    icon: Clock,
    isUnlocked: true,
    rarity: "rare" as const,
  },
  {
    title: "Legendary Learner",
    description: "Reach Level 20",
    icon: Award,
    isUnlocked: false,
    progress: 12,
    target: 20,
    rarity: "legendary" as const,
  },
]

const completedExams = [
  { name: "Word Basics", score: 92, date: "Mar 8, 2026", xp: 150 },
  { name: "Excel Formulas", score: 85, date: "Mar 7, 2026", xp: 120 },
  { name: "PowerPoint Design", score: 100, date: "Mar 5, 2026", xp: 200 },
  { name: "Word Styles", score: 78, date: "Mar 3, 2026", xp: 100 },
]

const activeDays = [
  new Date(2026, 2, 4),
  new Date(2026, 2, 5),
  new Date(2026, 2, 6),
  new Date(2026, 2, 7),
  new Date(2026, 2, 8),
  new Date(2026, 2, 9),
  new Date(2026, 2, 10),
]

export default function ProfilePage() {
  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="flex h-20 w-20 items-center justify-center rounded-full bg-primary/20">
              <User className="h-10 w-10 text-primary" />
            </div>
            <div>
              <h1 className="text-2xl font-medium text-foreground">John Doe</h1>
              <p className="text-muted-foreground">john@example.com</p>
              <div className="flex items-center gap-2 mt-2">
                <Badge className="bg-primary/10 text-primary border-0">
                  Level 12
                </Badge>
                <Badge variant="secondary" className="bg-warning/10 text-warning border-0">
                  <Flame className="h-3 w-3 mr-1" />
                  7 day streak
                </Badge>
              </div>
            </div>
          </div>
          <Button variant="outline">
            <Settings className="mr-2 h-4 w-4" />
            Edit Profile
          </Button>
        </div>

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <Card className="border shadow-sm bg-primary/5">
            <CardContent className="p-5">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/20">
                  <Zap className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="text-2xl font-medium text-card-foreground">2,450</p>
                  <p className="text-xs text-muted-foreground">Total XP</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="border shadow-sm">
            <CardContent className="p-5">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-muted">
                  <Trophy className="h-5 w-5 text-muted-foreground" />
                </div>
                <div>
                  <p className="text-2xl font-medium text-card-foreground">#4</p>
                  <p className="text-xs text-muted-foreground">Global Rank</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="border shadow-sm">
            <CardContent className="p-5">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-muted">
                  <CheckCircle2 className="h-5 w-5 text-muted-foreground" />
                </div>
                <div>
                  <p className="text-2xl font-medium text-card-foreground">48</p>
                  <p className="text-xs text-muted-foreground">Quizzes Completed</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="border shadow-sm">
            <CardContent className="p-5">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-muted">
                  <TrendingUp className="h-5 w-5 text-muted-foreground" />
                </div>
                <div>
                  <p className="text-2xl font-medium text-card-foreground">85%</p>
                  <p className="text-xs text-muted-foreground">Avg. Accuracy</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          <div className="lg:col-span-2">
            <Tabs defaultValue="badges" className="space-y-4">
              <TabsList className="bg-muted">
                <TabsTrigger value="badges">Badges</TabsTrigger>
                <TabsTrigger value="history">Quiz History</TabsTrigger>
                <TabsTrigger value="stats">Statistics</TabsTrigger>
              </TabsList>

              <TabsContent value="badges" className="space-y-4">
                <div className="flex items-center justify-between">
                  <p className="text-sm text-muted-foreground">
                    5 of 8 badges unlocked
                  </p>
                </div>
                <div className="grid gap-3 sm:grid-cols-2">
                  {badges.map((badge, index) => (
                    <BadgeCard key={index} {...badge} />
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="history" className="space-y-4">
                <Card className="border shadow-sm">
                  <CardContent className="p-0">
                    <div className="divide-y divide-border">
                      {completedExams.map((exam, index) => (
                        <div
                          key={index}
                          className="flex items-center justify-between p-4"
                        >
                          <div className="flex items-center gap-3">
                            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-muted">
                              <BookOpen className="h-5 w-5 text-muted-foreground" />
                            </div>
                            <div>
                              <p className="text-sm font-medium text-card-foreground">
                                {exam.name}
                              </p>
                              <p className="text-xs text-muted-foreground">
                                {exam.date}
                              </p>
                            </div>
                          </div>
                          <div className="flex items-center gap-4">
                            <div className="text-right">
                              <p
                                className={`text-sm font-medium ${
                                  exam.score >= 90
                                    ? "text-success"
                                    : exam.score >= 70
                                    ? "text-card-foreground"
                                    : "text-warning"
                                }`}
                              >
                                {exam.score}%
                              </p>
                              <p className="text-xs text-muted-foreground">Score</p>
                            </div>
                            <div className="text-right">
                              <p className="text-sm font-medium text-primary">
                                +{exam.xp}
                              </p>
                              <p className="text-xs text-muted-foreground">XP</p>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="stats" className="space-y-4">
                <Card className="border shadow-sm">
                  <CardHeader>
                    <CardTitle className="text-lg font-medium">
                      Performance by Category
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {[
                      { category: "Microsoft Word", accuracy: 88, quizzes: 15 },
                      { category: "Microsoft Excel", accuracy: 72, quizzes: 12 },
                      { category: "Microsoft PowerPoint", accuracy: 95, quizzes: 10 },
                      { category: "Adobe Photoshop", accuracy: 65, quizzes: 8 },
                    ].map((stat, index) => (
                      <div key={index} className="space-y-2">
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-card-foreground">{stat.category}</span>
                          <span className="text-muted-foreground">
                            {stat.accuracy}% ({stat.quizzes} quizzes)
                          </span>
                        </div>
                        <div className="h-2 rounded-full bg-muted">
                          <div
                            className={`h-2 rounded-full transition-all ${
                              stat.accuracy >= 85
                                ? "bg-success"
                                : stat.accuracy >= 70
                                ? "bg-primary"
                                : "bg-warning"
                            }`}
                            style={{ width: `${stat.accuracy}%` }}
                          />
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>

          <div>
            <StreakCalendar
              currentStreak={7}
              longestStreak={14}
              activeDays={activeDays}
            />
          </div>
        </div>
      </div>
    </DashboardLayout>
  )
}
