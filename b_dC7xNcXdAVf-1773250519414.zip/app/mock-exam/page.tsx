import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  Clock,
  FileText,
  Target,
  AlertCircle,
  ArrowRight,
  CheckCircle2,
  Trophy,
} from "lucide-react"
import Link from "next/link"

const mockExams = [
  {
    id: "mos-word-full",
    title: "Microsoft Word Specialist - Full Exam",
    description: "Complete simulation of the Certiport MOS Word certification exam",
    questionCount: 45,
    duration: "50 min",
    passingScore: 70,
    attempts: 2,
    bestScore: 82,
    lastAttempt: "Mar 5, 2026",
  },
  {
    id: "mos-excel-full",
    title: "Microsoft Excel Specialist - Full Exam",
    description: "Complete simulation of the Certiport MOS Excel certification exam",
    questionCount: 50,
    duration: "50 min",
    passingScore: 70,
    attempts: 1,
    bestScore: 68,
    lastAttempt: "Mar 2, 2026",
  },
  {
    id: "mos-powerpoint-full",
    title: "Microsoft PowerPoint - Full Exam",
    description: "Complete simulation of the Certiport MOS PowerPoint certification exam",
    questionCount: 35,
    duration: "50 min",
    passingScore: 70,
    attempts: 3,
    bestScore: 94,
    lastAttempt: "Mar 8, 2026",
  },
  {
    id: "adobe-photoshop-full",
    title: "Adobe Photoshop - Full Exam",
    description: "Complete simulation of the Adobe Certified Professional exam",
    questionCount: 55,
    duration: "60 min",
    passingScore: 63,
    attempts: 0,
    bestScore: null,
    lastAttempt: null,
  },
]

export default function MockExamPage() {
  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-medium text-foreground">Mock Exam Simulation</h1>
          <p className="mt-1 text-muted-foreground">
            Experience the real exam environment with timing and scoring
          </p>
        </div>

        <Card className="border border-primary/20 bg-primary/5 shadow-sm">
          <CardContent className="p-5">
            <div className="flex items-start gap-4">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary/20">
                <AlertCircle className="h-5 w-5 text-primary" />
              </div>
              <div>
                <h3 className="font-medium text-card-foreground">Before You Start</h3>
                <ul className="mt-2 space-y-1 text-sm text-muted-foreground">
                  <li>Make sure you have a stable internet connection</li>
                  <li>Find a quiet place where you won&apos;t be interrupted</li>
                  <li>The exam will auto-submit when time runs out</li>
                  <li>You can pause the exam, but the timer will continue</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid gap-4 lg:grid-cols-2">
          {mockExams.map((exam) => {
            const isPassed = exam.bestScore !== null && exam.bestScore >= exam.passingScore

            return (
              <Card key={exam.id} className="border shadow-sm">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <CardTitle className="text-lg font-medium">
                        {exam.title}
                      </CardTitle>
                      <p className="mt-1 text-sm text-muted-foreground">
                        {exam.description}
                      </p>
                    </div>
                    {isPassed && (
                      <Badge className="bg-success/10 text-success border-0 shrink-0">
                        <CheckCircle2 className="h-3 w-3 mr-1" />
                        Passed
                      </Badge>
                    )}
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-3 gap-4 text-center">
                    <div className="rounded-lg bg-muted/50 p-3">
                      <FileText className="h-4 w-4 mx-auto text-muted-foreground mb-1" />
                      <p className="text-sm font-medium text-card-foreground">
                        {exam.questionCount}
                      </p>
                      <p className="text-xs text-muted-foreground">Questions</p>
                    </div>
                    <div className="rounded-lg bg-muted/50 p-3">
                      <Clock className="h-4 w-4 mx-auto text-muted-foreground mb-1" />
                      <p className="text-sm font-medium text-card-foreground">
                        {exam.duration}
                      </p>
                      <p className="text-xs text-muted-foreground">Duration</p>
                    </div>
                    <div className="rounded-lg bg-muted/50 p-3">
                      <Target className="h-4 w-4 mx-auto text-muted-foreground mb-1" />
                      <p className="text-sm font-medium text-card-foreground">
                        {exam.passingScore}%
                      </p>
                      <p className="text-xs text-muted-foreground">Pass Score</p>
                    </div>
                  </div>

                  {exam.attempts > 0 && (
                    <div className="flex items-center justify-between rounded-lg bg-muted/50 px-4 py-3">
                      <div>
                        <p className="text-xs text-muted-foreground">
                          {exam.attempts} attempts - Last: {exam.lastAttempt}
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Trophy
                          className={`h-4 w-4 ${
                            isPassed ? "text-success" : "text-muted-foreground"
                          }`}
                        />
                        <span
                          className={`text-sm font-medium ${
                            isPassed ? "text-success" : "text-card-foreground"
                          }`}
                        >
                          Best: {exam.bestScore}%
                        </span>
                      </div>
                    </div>
                  )}

                  <Button className="w-full" asChild>
                    <Link href={`/practice?exam=${exam.id}&mode=test`}>
                      {exam.attempts > 0 ? "Retake Exam" : "Start Exam"}
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                </CardContent>
              </Card>
            )
          })}
        </div>

        <Card className="border shadow-sm">
          <CardHeader>
            <CardTitle className="text-lg font-medium flex items-center gap-2">
              <Trophy className="h-5 w-5 text-primary" />
              Your Mock Exam Statistics
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 sm:grid-cols-4">
              <div className="rounded-lg bg-muted/50 p-4 text-center">
                <p className="text-2xl font-medium text-card-foreground">6</p>
                <p className="text-xs text-muted-foreground">Total Attempts</p>
              </div>
              <div className="rounded-lg bg-muted/50 p-4 text-center">
                <p className="text-2xl font-medium text-success">2</p>
                <p className="text-xs text-muted-foreground">Exams Passed</p>
              </div>
              <div className="rounded-lg bg-muted/50 p-4 text-center">
                <p className="text-2xl font-medium text-card-foreground">81%</p>
                <p className="text-xs text-muted-foreground">Avg. Score</p>
              </div>
              <div className="rounded-lg bg-muted/50 p-4 text-center">
                <p className="text-2xl font-medium text-primary">94%</p>
                <p className="text-xs text-muted-foreground">Best Score</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}
