import { DashboardLayout } from "@/components/dashboard-layout"
import { StatCard } from "@/components/stat-card"
import { ExamCard } from "@/components/exam-card"
import { MissionCard } from "@/components/mission-card"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  Target,
  Zap,
  Clock,
  TrendingUp,
  ArrowRight,
  Award,
  Trophy,
  Flame,
} from "lucide-react"
import Link from "next/link"
import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import {
  getUserStats,
  getUserMissions,
  getExams,
  getLeaderboard,
  getRecentAttempts,
  assignDailyMissions,
} from "@/lib/database"

export default async function DashboardPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  
  if (!user) {
    redirect("/auth/login")
  }

  // Assign daily missions if needed
  await assignDailyMissions(user.id)

  // Fetch all data in parallel
  const [stats, missions, exams, leaderboard, recentAttempts] = await Promise.all([
    getUserStats(user.id),
    getUserMissions(user.id),
    getExams(),
    getLeaderboard("all"),
    getRecentAttempts(user.id, 10),
  ])

  const displayName = stats.profile?.display_name || user.email?.split("@")[0] || "User"
  const totalXp = stats.profile?.total_xp || 0
  const currentStreak = stats.profile?.current_streak || 0
  const level = Math.floor(totalXp / 500) + 1

  // Calculate available XP from incomplete missions
  const availableXp = missions
    .filter(m => !m.is_completed)
    .reduce((sum, m) => sum + (m.mission?.xp_reward || 0), 0)

  // Find user's rank in leaderboard
  const userRank = leaderboard.findIndex(p => p.id === user.id) + 1

  // Calculate exam progress based on recent attempts
  const examProgress = new Map<string, number>()
  for (const attempt of recentAttempts) {
    if (attempt.exam_id) {
      const current = examProgress.get(attempt.exam_id) || 0
      examProgress.set(attempt.exam_id, Math.max(current, attempt.score))
    }
  }

  // Map exams with progress
  const examCards = exams.slice(0, 4).map(exam => ({
    id: exam.id,
    title: exam.name,
    description: exam.description || "",
    questionCount: 0, // Will be populated from questions table
    duration: `${exam.time_limit_minutes} min`,
    progress: examProgress.get(exam.id) || 0,
    difficulty: exam.difficulty as "Easy" | "Medium" | "Hard",
  }))

  // Map missions for display
  const missionCards = missions.map(um => ({
    title: um.mission?.name || "Mission",
    description: um.mission?.description || "",
    xpReward: um.mission?.xp_reward || 0,
    progress: um.current_progress,
    target: um.mission?.target_value || 1,
    isCompleted: um.is_completed,
  }))

  // Create leaderboard display data
  const leaderboardData = leaderboard.slice(0, 5).map((profile, index) => ({
    rank: index + 1,
    name: profile.display_name || "Anonymous",
    xp: profile.total_xp,
    avatar: (profile.display_name || "A").slice(0, 2).toUpperCase(),
    isCurrentUser: profile.id === user.id,
  }))

  // If user is not in top 5, add them
  if (userRank > 5) {
    leaderboardData.push({
      rank: userRank,
      name: displayName,
      xp: totalXp,
      avatar: displayName.slice(0, 2).toUpperCase(),
      isCurrentUser: true,
    })
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-medium text-foreground">
            Welcome back, {displayName}!
          </h1>
          <p className="mt-1 text-muted-foreground">
            {"You're making great progress. Keep it up!"}
          </p>
        </div>

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard
            title="Exam Readiness"
            value={`${stats.avgScore}%`}
            subtitle="Average score"
            icon={Target}
            trend={{ value: 5, isPositive: true }}
            variant="primary"
          />
          <StatCard
            title="Total XP"
            value={totalXp.toLocaleString()}
            subtitle={`Level ${level}`}
            icon={Zap}
            trend={{ value: 12, isPositive: true }}
            variant="success"
          />
          <StatCard
            title="Quizzes Completed"
            value={stats.quizzesCompleted.toString()}
            subtitle="Total attempts"
            icon={Clock}
            trend={{ value: 8, isPositive: true }}
          />
          <StatCard
            title="Badges Earned"
            value={stats.badgesCount.toString()}
            subtitle="Achievements unlocked"
            icon={TrendingUp}
            trend={{ value: 3, isPositive: true }}
          />
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-medium text-foreground">
                Continue Practicing
              </h2>
              <Button variant="ghost" size="sm" asChild>
                <Link href="/practice">
                  View All <ArrowRight className="ml-1 h-4 w-4" />
                </Link>
              </Button>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              {examCards.map((exam) => (
                <ExamCard key={exam.id} {...exam} />
              ))}
            </div>
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-medium text-foreground">
                Daily Missions
              </h2>
              <Badge variant="secondary" className="bg-primary/10 text-primary border-0">
                +{availableXp} XP available
              </Badge>
            </div>
            <div className="space-y-3">
              {missionCards.length > 0 ? (
                missionCards.map((mission, index) => (
                  <MissionCard key={index} {...mission} />
                ))
              ) : (
                <Card className="border shadow-sm">
                  <CardContent className="py-8 text-center text-muted-foreground">
                    Complete a quiz to unlock daily missions!
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          <Card className="lg:col-span-2 border shadow-sm">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg font-medium">
                  Recent Activity
                </CardTitle>
                <Button variant="ghost" size="sm" asChild>
                  <Link href="/profile">View History</Link>
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentAttempts.length > 0 ? (
                  recentAttempts.slice(0, 4).map((attempt) => (
                    <div key={attempt.id} className="flex items-center gap-4">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-sm font-medium text-card-foreground">
                            {attempt.exam?.name || "Quiz"}
                          </span>
                          <span className="text-sm text-muted-foreground">
                            {attempt.score}%
                          </span>
                        </div>
                        <div className="h-2 rounded-full bg-muted">
                          <div
                            className={`h-2 rounded-full transition-all ${
                              attempt.score < 65
                                ? "bg-destructive"
                                : attempt.score < 75
                                ? "bg-warning"
                                : "bg-success"
                            }`}
                            style={{ width: `${attempt.score}%` }}
                          />
                        </div>
                      </div>
                      <Badge variant="outline" className="shrink-0">
                        +{attempt.xp_earned} XP
                      </Badge>
                    </div>
                  ))
                ) : (
                  <div className="py-8 text-center text-muted-foreground">
                    No quizzes completed yet. Start practicing to see your progress!
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          <Card className="border shadow-sm">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg font-medium flex items-center gap-2">
                  <Trophy className="h-5 w-5 text-primary" />
                  Leaderboard
                </CardTitle>
                <Button variant="ghost" size="sm" asChild>
                  <Link href="/leaderboard">View All</Link>
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {leaderboardData.map((person) => (
                  <div
                    key={person.rank}
                    className={`flex items-center gap-3 rounded-lg p-2 ${
                      person.isCurrentUser ? "bg-primary/10" : ""
                    }`}
                  >
                    <div
                      className={`flex h-6 w-6 items-center justify-center rounded-full text-xs font-medium ${
                        person.rank === 1
                          ? "bg-yellow-500/20 text-yellow-600"
                          : person.rank === 2
                          ? "bg-gray-300/30 text-gray-600"
                          : person.rank === 3
                          ? "bg-amber-600/20 text-amber-700"
                          : "bg-muted text-muted-foreground"
                      }`}
                    >
                      {person.rank}
                    </div>
                    <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/20 text-xs font-medium text-primary">
                      {person.avatar}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-card-foreground truncate">
                        {person.name}
                        {person.isCurrentUser && (
                          <span className="ml-1 text-xs text-muted-foreground">
                            (You)
                          </span>
                        )}
                      </p>
                    </div>
                    <div className="flex items-center gap-1">
                      <Zap className="h-3.5 w-3.5 text-primary" />
                      <span className="text-sm font-medium text-card-foreground">
                        {person.xp.toLocaleString()}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        <Card className="border shadow-sm bg-primary/5">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-primary">
                  <Award className="h-7 w-7 text-primary-foreground" />
                </div>
                <div>
                  <h3 className="text-lg font-medium text-card-foreground">
                    Ready for the Real Exam?
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    Take a full mock exam simulation with real timing and scoring
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-1 text-sm text-muted-foreground">
                  <Flame className="h-4 w-4 text-warning" />
                  <span>{currentStreak} day streak</span>
                </div>
                <Button asChild>
                  <Link href="/mock-exam">
                    Start Mock Exam
                    <ArrowRight className="ml-1 h-4 w-4" />
                  </Link>
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}
