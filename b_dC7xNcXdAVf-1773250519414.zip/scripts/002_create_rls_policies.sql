-- Enable RLS on all tables
ALTER TABLE public.schools ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.exam_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.exams ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.questions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.quiz_attempts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.question_responses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.badges ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_badges ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.missions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_missions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.activity_log ENABLE ROW LEVEL SECURITY;

-- Schools: Anyone can read
CREATE POLICY "schools_select_all" ON public.schools FOR SELECT USING (true);

-- Profiles: Users can read all profiles (for leaderboard), but only update own
CREATE POLICY "profiles_select_all" ON public.profiles FOR SELECT USING (true);
CREATE POLICY "profiles_insert_own" ON public.profiles FOR INSERT WITH CHECK (auth.uid() = id);
CREATE POLICY "profiles_update_own" ON public.profiles FOR UPDATE USING (auth.uid() = id);
CREATE POLICY "profiles_delete_own" ON public.profiles FOR DELETE USING (auth.uid() = id);

-- Exam categories: Anyone can read
CREATE POLICY "exam_categories_select_all" ON public.exam_categories FOR SELECT USING (true);

-- Exams: Anyone can read
CREATE POLICY "exams_select_all" ON public.exams FOR SELECT USING (true);

-- Questions: Anyone can read
CREATE POLICY "questions_select_all" ON public.questions FOR SELECT USING (true);

-- Quiz attempts: Users can read all (for leaderboard), manage own
CREATE POLICY "quiz_attempts_select_all" ON public.quiz_attempts FOR SELECT USING (true);
CREATE POLICY "quiz_attempts_insert_own" ON public.quiz_attempts FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "quiz_attempts_update_own" ON public.quiz_attempts FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "quiz_attempts_delete_own" ON public.quiz_attempts FOR DELETE USING (auth.uid() = user_id);

-- Question responses: Only own responses
CREATE POLICY "question_responses_select_own" ON public.question_responses 
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM public.quiz_attempts 
      WHERE quiz_attempts.id = question_responses.attempt_id 
      AND quiz_attempts.user_id = auth.uid()
    )
  );
CREATE POLICY "question_responses_insert_own" ON public.question_responses 
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.quiz_attempts 
      WHERE quiz_attempts.id = attempt_id 
      AND quiz_attempts.user_id = auth.uid()
    )
  );

-- Badges: Anyone can read
CREATE POLICY "badges_select_all" ON public.badges FOR SELECT USING (true);

-- User badges: Anyone can read (for profiles), users manage own
CREATE POLICY "user_badges_select_all" ON public.user_badges FOR SELECT USING (true);
CREATE POLICY "user_badges_insert_own" ON public.user_badges FOR INSERT WITH CHECK (auth.uid() = user_id);

-- Missions: Anyone can read
CREATE POLICY "missions_select_all" ON public.missions FOR SELECT USING (true);

-- User missions: Users can read own, manage own
CREATE POLICY "user_missions_select_own" ON public.user_missions FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "user_missions_insert_own" ON public.user_missions FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "user_missions_update_own" ON public.user_missions FOR UPDATE USING (auth.uid() = user_id);

-- Activity log: Users can read own, insert own
CREATE POLICY "activity_log_select_own" ON public.activity_log FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "activity_log_insert_own" ON public.activity_log FOR INSERT WITH CHECK (auth.uid() = user_id);
